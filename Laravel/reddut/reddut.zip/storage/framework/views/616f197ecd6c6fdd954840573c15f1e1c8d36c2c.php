<div class="row">
  <div class="col-md-offset-3 col-md-9">
      <div class="row">
        <div class="col-md-1 flex-center">
          <?php echo $__env->make('../partials/votes', ['id' => $reply->id, 'score' => $reply->score, 'name' => 'comments'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-2 line-right">
          <p><?php echo e($reply->user->name); ?></p>
          <p><?php echo e(Carbon\Carbon::parse($reply->created_at)->format('d-m-Y H:i')); ?></p>
        </div>
        <div class="col-md-8">
          <p><?php echo e($reply->body); ?></p>
        </div>
        
        <?php echo $__env->make('../partials/showEditDeleteButtons', ['id' => $reply->id, 'name' => $reply->user->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      </div>
  </div>
</div>
