<?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <div class="well well-md">
    <div class="row">
      <div class="col-md-1 flex-center">
        <?php echo $__env->make('../partials/votes', ['id' => $comment->id, 'score' => $comment->score, 'name' => 'comments'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
      </div>
      <div class="col-md-2 line-right">
        <p><?php echo e($comment->user->name); ?></p>
        <p><?php echo e(Carbon\Carbon::parse($comment->created_at)->format('d-m-Y H:i')); ?></p>
      </div>
      <div class="col-md-8">
        <p><?php echo e($comment->body); ?></p>
      </div>
      
      <div class="col-md-1 flex-center">
        <?php if(Auth::check() && (Auth::user()->isAdmin || $comment->user->name == Auth::user()->name)): ?>
          <form action="<?php echo e(url('/comments/' . $comment->id . '/edit')); ?>" method="post">
            <?php echo e(csrf_field()); ?>


              <button type="submit" name="button" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></button>
          </form><br>
          <form action="<?php echo e(url('/comments/' . $comment->id)); ?>" method="post">
            <?php echo e(csrf_field()); ?>

              <input type="hidden" name="_method" value="DELETE">

              <button type="submit" name="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-trash"></i></button>
          </form>
        <?php endif; ?>
      </div>
    </div>
  </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
