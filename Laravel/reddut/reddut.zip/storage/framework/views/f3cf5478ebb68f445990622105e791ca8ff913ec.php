<?php $__env->startSection('navbar'); ?>
  <a class="navbar-brand" href="/posts">Terug naar Posts</a>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
  <h2><?php echo e($post->title); ?></h2>
  <hr>
  <div class="well well-lg">
        <form class="form-horizontal" action="/posts/<?php echo e($post->id); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <input type="hidden" name="_method" value="PATCH">
            <div class="form-group">
              <label class="control-label col-sm-2" for="title">Title:</label>
              <div class="col-sm-10">
                <input type="text" class="form-control" id="title" name="title" placeholder="Enter title" value="<?php echo e($post->title); ?>">
              </div>
            </div>
            <div class="form-group">
              <label class="control-label col-sm-2" for="body">Body:</label>
              <div class="col-sm-10">
                <textarea name="body" id="body" class="form-control" ><?php echo e($post->body); ?></textarea>
              </div>
            </div>
            <div class="form-group">
            <div class="col-sm-offset-2 col-sm-10">
              <button type="submit" class="btn btn-primary">Update Post</button>
            </div>
            </div>
        </form>
  </div>

  <?php if(count($errors)): ?>
    <div class="alert alert-warning alert-dismissable fade in">
      <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
          <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
      </ul>
    </div>
  <?php endif; ?>
  <hr>
  <h3>Voeg een comment toe:</h3>
  <form class="form-horizontal" action="/posts/<?php echo e($post->id); ?>/comment" method="POST">

      <?php echo e(csrf_field()); ?>


    <div class="form-group">
      <label class="control-label col-sm-2" for="body">Comment:</label>
      <div class="col-sm-10">
        <textarea name="body" class="form-control" placeholder="Enter comment"><?php echo e(old('body')); ?></textarea>
      </div>
    </div>

    <div class="form-group">
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" class="btn btn-default">Add Comment</button>
      </div>
    </div>

  </form>
  <hr>
  <h1>Comments</h1>

  <?php $__currentLoopData = $comments; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $comment): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="well well-md">
      <div class="row">
        <div class="col-md-1">
          <p><i class="glyphicon glyphicon-chevron-up"></i></p>
          <p><i class="glyphicon glyphicon-chevron-down"></i></p>
        </div>
        <div class="col-md-1">
          <p class="text-center"><?php echo e($comment->score); ?></p>
        </div>
        <div class="col-md-9">
          <p><?php echo e($comment->body); ?></p>
          <i>-<?php echo e($comment->user->name); ?></i>
        </div>
        <div class="col-md-1">
          <?php if($comment->user->name == Auth::user()->name): ?>
            <form action="/posts/<?php echo e($post->id); ?>/edit" method="post">
              <?php echo e(csrf_field()); ?>


                <button type="submit" name="button" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></button>
            </form><br>
            <form action="/comments/<?php echo e($comment->id); ?>" method="post">
              <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE">

                <button type="submit" name="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-trash"></i></button>
            </form>
          <?php endif; ?>
        </div>
      </div>
    </div>
  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
  <hr>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>