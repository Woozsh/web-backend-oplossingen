<div class="row">
  <div class="col-md-offset-1 col-md-11">
      <div class="row">
        <div class="col-md-1 flex-center">
          <?php echo $__env->make('../partials/votes', ['id' => $reply->id, 'score' => $reply->score, 'name' => 'comments'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
        </div>
        <div class="col-md-2 line-right">
          <p><?php echo e($reply->user->name); ?></p>
          <p><?php echo e(Carbon\Carbon::parse($reply->created_at)->format('d-m-Y H:i')); ?></p>
        </div>
        <div class="col-md-8">
          <p><?php echo e($reply->body); ?></p>
        </div>
        
        <?php echo $__env->make('../partials/showEditDeleteButtons', ['id' => $reply->id, 'name' => $reply->user->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      </div>
  </div>
</div>

<div class="row">
  <div class="col-md-offset-4 col-md-7">

    <?php if(Auth::check()): ?>
      <form action="<?php echo e(url('/posts/reply/' . $reply->id)); ?>" method="post">
          <?php echo e(csrf_field()); ?>

            <div class="input-group">
              <input type="text" class="form-control" id="body" name="body" placeholder="Enter reply on Comment">
              <span class="input-group-btn">
                <button class="btn btn-default" type="submit">Reply</button>
              </span>
            </div>
      </form>
    <?php endif; ?>

  </div>
  <div class="col-md-1">

  </div>
</div> 
<?php $__currentLoopData = $reply->children; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $reply): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
  <?php echo $__env->make('../partials/showReplies2', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
