<?php $__env->startSection('title'); ?>
  Reddut - Posts
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
  <?php if(Auth::check()): ?>
    <h1>Start een nieuwe post</h1>

    <?php if(count($errors)): ?>
      <div class="alert alert-warning alert-dismissable fade in">
        <a href="#" class="close" data-dismiss="alert" aria-label="close">&times;</a>
        <ul>
          <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
            <li><?php echo e($error); ?></li>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
        </ul>
      </div>
    <?php endif; ?>

      <form class="form-horizontal" action="posts" method="POST">

        <?php echo e(csrf_field()); ?>


        <div class="form-group">
          <label class="control-label col-sm-2" for="title">Title:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="title" name="title" placeholder="Enter title" value="<?php echo e(old('title')); ?>">
          </div>
        </div>
        <div class="form-group">
          <label class="control-label col-sm-2" for="body">Body:</label>
          <div class="col-sm-10">
            <input type="text" class="form-control" id="body" name="body" placeholder="Enter body" value="<?php echo e(old('body')); ?>">
          </div>
        </div>
      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default">Make Post</button>
        </div>
      </div>
    </form>
  <?php else: ?>
    <div class="alert alert-warning">
      Make an account or log in to make posts or comments.
    </div>
  <?php endif; ?>



  <h1>Alle Posts</h1>
  <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getFirstLoop(); ?>
    <div class="well post">
      <div class="row">
        <div class="col-md-2 flex-center">
          <form action="/posts/<?php echo e($post->id); ?>/upvote" method="post">
              <?php echo e(csrf_field()); ?>


              <button type="submit" name="button" class="no-btn glyphicon glyphicon-chevron-up"></button>
          </form>
          Score: <?php echo e($post->score); ?>

          <form action="/posts/<?php echo e($post->id); ?>/downvote" method="post">
              <?php echo e(csrf_field()); ?>


              <button type="submit" name="button" class="no-btn glyphicon glyphicon-chevron-down"></button>
          </form>
        </div>
        <div class="col-md-9">
          <h3><?php echo e($post->title); ?></h3>
          <a class="post" href="posts/<?php echo e($post->id); ?>">
            <p>reacties: <?php echo e(count($post->comments)); ?></p>
            <p><?php echo e(Carbon\Carbon::parse($post->created_at)->format('d-m-Y H:i:s')); ?> by <i><?php echo e($post->user->name); ?></i></p>
          </a>
        </div>
        <?php if(Auth::check() && $post->user->name == Auth::user()->name): ?>
          <div class="col-md-1">
            <form action="/posts/<?php echo e($post->id); ?>/edit" method="post">
              <?php echo e(csrf_field()); ?>


                <button type="submit" name="button" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></button>
            </form><br>
            <form action="/posts/<?php echo e($post->id); ?>" method="post">
              <?php echo e(csrf_field()); ?>

                <input type="hidden" name="_method" value="DELETE">

                <button type="submit" name="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-trash"></i></button>
            </form>
          </div>
        <?php endif; ?>
      </div>
    </div>

  <?php endforeach; $__env->popLoop(); $loop = $__env->getFirstLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>