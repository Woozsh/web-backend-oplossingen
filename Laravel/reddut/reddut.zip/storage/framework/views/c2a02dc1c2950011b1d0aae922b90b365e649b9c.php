<div class="col-md-1 flex-center">
  <?php if(Auth::check() && (Auth::user()->isAdmin || $name == Auth::user()->name)): ?>
    <form action="<?php echo e(url('/comments/' . $id . '/edit')); ?>" method="post">
      <?php echo e(csrf_field()); ?>


        <button type="submit" name="button" class="btn btn-primary btn-sm"><i class="glyphicon glyphicon-edit"></i></button>
    </form><br>
    <form action="<?php echo e(url('/comments/' . $id)); ?>" method="post">
      <?php echo e(csrf_field()); ?>

        <input type="hidden" name="_method" value="DELETE">

        <button type="submit" name="button" class="btn btn-danger btn-sm"><i class="glyphicon glyphicon-trash"></i></button>
    </form>
  <?php endif; ?>
</div>
