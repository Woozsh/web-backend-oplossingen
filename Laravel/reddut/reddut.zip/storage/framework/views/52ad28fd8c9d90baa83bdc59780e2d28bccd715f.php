<?php $__env->startSection('content'); ?>

  <h1>Page not found.</h1>
  <p><a href="/posts/">Return.</a></p>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>