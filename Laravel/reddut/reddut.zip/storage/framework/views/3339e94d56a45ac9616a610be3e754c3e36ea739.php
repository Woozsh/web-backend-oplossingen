<form <?php if(Auth::check()): ?>action="/<?php echo e($name); ?>/<?php echo e($id); ?>/upvote"<?php endif; ?> method="post">
    <?php echo e(csrf_field()); ?>


    <button type="submit" name="button" class="no-btn glyphicon glyphicon-chevron-up"></button>
</form>
Score: <?php echo e($score); ?>

<form <?php if(Auth::check()): ?>action="/<?php echo e($name); ?>/<?php echo e($id); ?>/downvote"<?php endif; ?> method="post">
    <?php echo e(csrf_field()); ?>


    <button type="submit" name="button" class="no-btn glyphicon glyphicon-chevron-down"></button>
</form>
