<?php $__env->startSection('navbar'); ?>
  <a class="navbar-brand" href="<?php echo e(url('/posts')); ?>">Terug naar Posts</a>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>



  <?php if($post->link !== ''): ?>
    <a href="<?php echo e($post->link); ?>"><h3><?php echo e($post->title); ?></h3></a>
  <?php else: ?>
    <h2><?php echo e($post->title); ?></h2>
  <?php endif; ?>

    <i><?php echo e($post->user->name); ?></i>

  <hr>
  <div class="well well-lg post">
    <div class="row">
      <div class="col-md-2 flex-center">

        <?php echo $__env->make('../partials/votes', ['id' => $post->id, 'score' => $post->score, 'name' => 'posts'], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

      </div>

      <div class="col-md-9">
        <p><?php echo e($post->body); ?></p>
      </div>

      <?php echo $__env->make('../partials/showEditDeleteButtons', ['id' => $post->id, 'name' => $post->user->name], array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    </div>
  </div>
  <hr>





  <?php if(Auth::check()): ?>
    <h3>Voeg een comment toe:</h3>

    <?php echo $__env->make('../partials/alerts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

    <form class="form-horizontal" action="<?php echo e(url('/posts/' . $post->id . '/comment')); ?>" method="post">


        <?php echo e(csrf_field()); ?>


      <div class="form-group">
        <label class="control-label col-sm-2" for="body">Comment:</label>
        <div class="col-sm-10">
          <textarea name="body" class="form-control" placeholder="Enter comment"><?php echo e(old('body')); ?></textarea>
        </div>
      </div>

      <div class="form-group">
        <div class="col-sm-offset-2 col-sm-10">
          <button type="submit" class="btn btn-default">Add Comment</button>
        </div>
      </div>

    </form>
    <hr>
  <?php else: ?>
    <div class="alert alert-warning">
      Make an account or log in to post a comment.
    </div>
  <?php endif; ?>



  <h1>Comments</h1>

  <?php echo $__env->make('../partials/showComments', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

  <hr>




<?php $__env->stopSection(); ?>

<?php echo $__env->make('layout', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>