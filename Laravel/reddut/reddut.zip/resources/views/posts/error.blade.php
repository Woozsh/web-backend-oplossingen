@extends('layout')
@section('content')

  <h1>Page not found.</h1>
  <p><a href="/posts/">Return.</a></p>
@endsection
